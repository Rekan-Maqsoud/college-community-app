Report Review Proxy (Appwrite Function)

This function receives review requests from the app and forwards them to Discord.

Required function env vars:
- APPWRITE_ENDPOINT
- APPWRITE_PROJECT_ID
- DISCORD_REVIEW_WEBHOOK_URL

Entrypoint:
- src/main.js
